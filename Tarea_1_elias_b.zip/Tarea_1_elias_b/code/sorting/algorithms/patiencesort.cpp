#include <iostream>
#include <vector>
#include <queue>

using namespace std ;

void patience_sort(vector<int>& a) {
    vector<vector<int>> pila ;

    // 1. Fase de construcción de pilas con BÚSQUEDA BINARIA
    for (size_t i = 0 ; i < a.size() ; i++) {
        int l = 0, r = pila.size() - 1 ;
        int indice = -1 ;
        
        // Búsqueda binaria para encontrar la pila más a la izquierda 
        // cuyo tope sea mayor o IGUAL al elemento actual
        while (l <= r) {
            int m = l + (r - l) / 2 ;
            if (pila[m].back() >= a[i]) { 
                indice = m ;
                r = m - 1 ; // Buscamos más a la izquierda
            } else {
                l = m + 1 ;
            }
        }

        if (indice != -1) {
            pila[indice].push_back(a[i]) ;
        } else {
            pila.push_back({a[i]}) ; // Crea una nueva pila
        }
    }

    // 2. Fase de fusión usando una COLA DE PRIORIDAD (Min-Heap)
    // Guarda pares de la forma: {valor_tope, indice_de_la_pila}
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq ;
    
    // Insertamos el tope de cada pila en el Min-Heap
    for (size_t i = 0 ; i < pila.size() ; i++) {
        if (!pila[i].empty()) {
            pq.push({pila[i].back(), i}) ;
        }
    }

    int k = 0 ;
    // Extraemos el mínimo global continuamente
    while (!pq.empty()) {
        auto [val, p_idx] = pq.top() ; // C++17 feature: Structured binding
        pq.pop() ;
        a[k++] = val ;
        
        // Sacamos el elemento de la pila correspondiente
        pila[p_idx].pop_back() ;
        
        // Si la pila no quedó vacía, metemos su nuevo tope al Heap
        if (!pila[p_idx].empty()) {
            pq.push({pila[p_idx].back(), p_idx}) ;
        }
    }
}

int patience_main(vector<int>& array){
    if(array.empty()) return 0 ;
    patience_sort(array) ;
    return 0 ;
}

// Fuentes: Optimización de Patience Sort con Binary Search y Min-Heap.
// Fuentes: https://www.geeksforgeeks.org/dsa/patience-sorting/
