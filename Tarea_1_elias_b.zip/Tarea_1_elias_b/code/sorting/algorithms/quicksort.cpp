#include <iostream>
#include <vector>

using namespace std ;

// Función que maneja los 3 punteros y actualiza los límites por referencia
void particion_3_vias(vector<int>& a, int l, int h, int& lt, int& gt){
  
  // OPTIMIZACIÓN: Elegir el elemento central como pivote.
  // Esto evita el Stack Overflow y el O(N^2) en arreglos ordenados o descendentes.
  int mid = l + (h - l) / 2 ;
  swap(a[l], a[mid]) ;

  int pivote = a[l] ; 
  lt = l ;
  gt = h ;
  int i = l + 1 ;

  while(i <= gt){
    if(a[i] < pivote){
      swap(a[lt], a[i]) ;
      lt++ ;
      i++ ;
    }
    else if(a[i] > pivote){
      swap(a[i], a[gt]) ;
      gt-- ;
    }
    else{
      i++ ;
    }
  }
}

void quick_sort(vector<int>& a, int l, int h){
  if(l < h){
    int lt, gt ;
    particion_3_vias(a, l, h, lt, gt) ;
    
    // Se excluyen los elementos iguales al pivote (que están entre lt y gt)
    quick_sort(a, l, lt - 1) ;
    quick_sort(a, gt + 1, h) ;
  }
}

int quick_main(vector<int>& array){
  if(array.empty()) return 0 ; // Previene errores con arreglos vacíos
  int n = array.size() ;
  quick_sort(array, 0, n - 1) ;
  return 0 ;
}

// Fuentes: https://www.geeksforgeeks.org/3-way-quicksort-dutch-national-flag/
