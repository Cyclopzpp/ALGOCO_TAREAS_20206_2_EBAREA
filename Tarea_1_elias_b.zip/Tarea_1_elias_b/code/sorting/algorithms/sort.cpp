#include <algorithm>
#include <vector>

using namespace std ;

vector<int> sortArray(vector<int>& arr) {
    sort(arr.begin(), arr.end());
    return arr;
}
