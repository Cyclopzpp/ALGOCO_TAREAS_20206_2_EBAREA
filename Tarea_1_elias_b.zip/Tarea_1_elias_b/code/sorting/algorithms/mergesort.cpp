#include <iostream>
#include <vector>

using namespace std ;

void merge_again(vector<int>& a, int l, int m, int r){
    int l_m = m - l + 1 ;
    int m_r = r - m ;
    vector<int> L(l_m), R(m_r) ;
    for(int i = 0 ; i < l_m ; i++) L[i] = a[l + i] ;
    for(int i = 0 ; i < m_r ; i++) R[i] = a[m + 1 + i] ;
    int i = 0, j = 0, k = l ;

    while(i < l_m && j < m_r){
        if(L[i] <= R[j]) a[k++] = L[i++] ;
        else a[k++] = R[j++] ;
    }

    while(i < l_m) a[k++] = L[i++] ;
    while(j < m_r) a[k++] = R[j++] ;
}

void merge_sort(vector<int>& a, int l, int r){
    if(l >= r) return ;

    int m = l + (r - l) / 2 ;
    merge_sort(a, l, m) ;
    merge_sort(a, m + 1, r) ;
    merge_again(a, l, m, r) ;
}

int merge_main(vector<int>& array){
    int n = array.size() ;
    merge_sort(array, 0, n - 1) ;
    return 0 ;
}

// Fuente: https://www.geeksforgeeks.org/dsa/merge-sort/