#include "./algorithms/sort.cpp"
#include "./algorithms/mergesort.cpp"
#include "./algorithms/quicksort.cpp"
#include "./algorithms/patiencesort.cpp"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <chrono>
#include <sys/resource.h>
#include <filesystem>

using namespace std ;
namespace fs = std::filesystem ;

long get_mem_usage() {
    struct rusage usage ;
    getrusage(RUSAGE_SELF, &usage) ;
    return usage.ru_maxrss ;
}

void save_array(const vector<int>& arr, const string& filepath) {
    ofstream out(filepath) ;
    if (!out.is_open()) {
        cerr << "Error al crear el archivo de salida: " << filepath << endl ;
        return ;
    }
    for (size_t i = 0 ; i < arr.size() ; ++i) {
        out << arr[i] << (i == arr.size() - 1 ? "" : " ") ;
    }
    out.close() ;
}

int main() {
    string input_dir = "./data/array_input/" ;
    string output_dir = "./data/array_output/" ;
    string measurements_dir = "./data/measurements/" ;
    
    if (!fs::exists(input_dir)) fs::create_directories(input_dir) ;
    if (!fs::exists(output_dir)) fs::create_directories(output_dir) ;
    if (!fs::exists(measurements_dir)) fs::create_directories(measurements_dir) ;

    // Se eliminó la creación global de outputCSV que estaba aquí.

    auto test_algorithm = [&](const string& algo_name, auto sort_func, const vector<int>& original_array, const string& filename) {
        vector<int> array_to_sort = original_array ;
        
        long mem_before = get_mem_usage() ;
        auto start_time = chrono::high_resolution_clock::now() ;
        
        sort_func(array_to_sort) ;
        
        auto end_time = chrono::high_resolution_clock::now() ;
        long mem_after = get_mem_usage() ;
        
        // Calculamos la memoria adicional utilizada por el algoritmo
        long mem_used = mem_after - mem_before ;
        
        chrono::duration<double, milli> duration = end_time - start_time ;
        
        string out_file = output_dir + filename + "_" + algo_name + "_out.txt" ;
        save_array(array_to_sort, out_file) ;
        
        // --- INICIO DE CAMBIOS ---
        // Generamos un nombre de archivo dinámico basado en el algoritmo
        string out_csv_file = measurements_dir + algo_name + "_sorting_measurements.csv";
        bool write_header = !fs::exists(out_csv_file) || fs::file_size(out_csv_file) == 0;
        
        ofstream csv(out_csv_file, ios::app); 
        if (write_header) {
            csv << "Algorithm,File,Time_ms,Memory_KB\n";
        }
        
        csv << algo_name << "," << filename << "," << duration.count() << "," << mem_used << "\n";
        csv.close();
        // --- FIN DE CAMBIOS ---
        
        // Notificación en consola actualizada
        cout << "[TERMINADO] Algoritmo: " << algo_name 
             << " | Archivo: " << filename 
             << " | Tiempo: " << duration.count() << " ms" 
             << " | Memoria Extra: " << mem_used << " KB" << endl;
    } ;

    for (const auto& entry : fs::directory_iterator(input_dir)) {
        if (entry.is_regular_file() && entry.path().extension() == ".txt") {
            string inputF = entry.path().string() ;
            string filename = entry.path().stem().string() ;

            vector<int> original_array ;
            ifstream in(inputF) ;
            if (!in.is_open()) {
                cerr << "Error abriendo archivo de entrada: " << inputF << endl ;
                continue ;
            }
            int k ;
            while (in >> k) {
                original_array.push_back(k) ;
            }
            in.close() ;
            
            test_algorithm("mergesort", merge_main, original_array, filename) ;
            test_algorithm("quicksort", quick_main, original_array, filename) ;
            test_algorithm("patiencesort", patience_main, original_array, filename) ;
            test_algorithm("sort", sortArray, original_array, filename) ;
        }
    }

    // Se eliminó la llamada global csv.close() que estaba aquí al final.
    return 0 ;
}
