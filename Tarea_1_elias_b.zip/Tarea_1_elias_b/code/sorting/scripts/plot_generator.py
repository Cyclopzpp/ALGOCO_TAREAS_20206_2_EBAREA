import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path as pth

# 1. Definir rutas
route = pth.cwd().parent
ms_path = route / "data" / "measurements" 
pt_path = route / "data" / "plots"

def process_sorting_data(filepath):
    df = pd.read_csv(filepath)
    # Extraer N, tipo de distribución, D_type y variante
    # Ejemplo: "100000_aleatorio_D7_b" -> N=100000, Type=aleatorio, D_type=D7, Variant=b
    df[['N', 'Distribution_Type', 'D_type', 'Variant']] = df['File'].str.split('_', expand=True)
    df['N'] = df['N'].astype(int)
    
    # Agrupamos por N y Distribution_Type (aleatorio, ascendente, descendente)
    grouped = df.groupby(['N', 'Distribution_Type'])[['Time_ms', 'Memory_KB']].mean().reset_index()
    return grouped

# 3. Función para graficar por separado
def plot_sorting_separated(df, algorithm_name, complexity, c_factor):
    
    # ---------------------------------------------------------
    # GRÁFICO 1: TIEMPO DE EJECUCIÓN
    # ---------------------------------------------------------
    plt.figure(figsize=(8, 6))
    
    # Graficar datos reales agrupados por la distribución de los datos
    for dist_type in df['Distribution_Type'].unique():
        subset = df[df['Distribution_Type'] == dist_type].sort_values('N')
        plt.plot(subset['N'], subset['Time_ms'], marker='o', label=f'Real: {dist_type}')
    
    # Curva teórica del peor caso
    n_values = np.sort(df['N'].unique())
    if complexity == "O(N log N)":
        theoretical_time = c_factor * n_values * np.log2(n_values)
    elif complexity == "O(N^2)": 
        theoretical_time = c_factor * (n_values ** 2)
    else:
        theoretical_time = c_factor * n_values # O(N) lineal

    plt.plot(n_values, theoretical_time, linestyle='--', color='red', label=f'Teórico Peor Caso: {complexity}')
    
    plt.title(f'{algorithm_name} - Tiempo de Ejecución')
    plt.xlabel('Tamaño del Arreglo (N)')
    plt.ylabel('Tiempo (ms)')
    plt.xscale('log', base=10) # Cambiado a base 10 (10, 1000, 100000...)
    plt.yscale('log', base=10)
    plt.legend()
    plt.grid(True, which="both", ls="-", alpha=0.2)
    plt.tight_layout()
    
    ruta_tiempo = pt_path / f"{algorithm_name.lower()}_time_graph.png"
    plt.savefig(ruta_tiempo, dpi=300)
    print(f"Guardado: {ruta_tiempo}")
    plt.close()

    # ---------------------------------------------------------
    # GRÁFICO 2: USO DE MEMORIA
    # ---------------------------------------------------------
    plt.figure(figsize=(8, 6))
    
    for dist_type in df['Distribution_Type'].unique():
        subset = df[df['Distribution_Type'] == dist_type].sort_values('N')
        plt.plot(subset['N'], subset['Memory_KB'], marker='s', label=f'Real: {dist_type}')
        
    plt.title(f'{algorithm_name} - Uso de Memoria')
    plt.xlabel('Tamaño del Arreglo (N)')
    plt.ylabel('Memoria (KB)')
    plt.xscale('log', base=10)
    
    # Si la memoria es 0 en muchos casos (como en In-place QuickSort), log dará error visual.
    # Por lo que es mejor dejar el eje Y en escala lineal para la memoria en ordenamiento.
    plt.legend()
    plt.grid(True, which="both", ls="-", alpha=0.2)
    plt.tight_layout()
    
    ruta_memoria = pt_path / f"{algorithm_name.lower()}_memory_graph.png"
    plt.savefig(ruta_memoria, dpi=300)
    print(f"Guardado: {ruta_memoria}")
    plt.close()

# 4. Cargar y procesar los datos
# Asegúrate de poner los nombres correctos de tus CSV
df_merge = process_sorting_data(ms_path / "mergesort_sorting_measurements.csv")
df_patience = process_sorting_data(ms_path / "patiencesort_sorting_measurements.csv")
df_quick = process_sorting_data(ms_path / "quicksort_sorting_measurements.csv")
df_sort = process_sorting_data(ms_path / "sort_sorting_measurements.csv")

# 5. Generar los gráficos por separado
# Ajusta el 'c_factor' probando diferentes valores (ej. 1e-4, 1e-5) para que 
# la línea punteada roja se alinee visualmente de forma paralela a tus puntos reales.
plot_sorting_separated(df_merge, "MergeSort", "O(N log N)", c_factor=1e-5)
plot_sorting_separated(df_patience, "PatienceSort", "O(N log N)", c_factor=1e-5)
plot_sorting_separated(df_quick, "QuickSort", "O(N^2)", c_factor=1e-7) # Peor caso teórico
plot_sorting_separated(df_sort, "Built-in Sort", "O(N log N)", c_factor=1e-6)
