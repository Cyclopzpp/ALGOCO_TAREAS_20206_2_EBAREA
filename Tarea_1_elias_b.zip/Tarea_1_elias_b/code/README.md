# Documentación

## Entrega

La entrega se realiza vía *aula.usm.cl* en formato Tarea_1_elias_b.zip.

## Multiplicación de matrices

Algoritmos: Naive, Strassen.

### Programa principal

matrix_multiplication.cpp: Lee las matrices de entrada desde data/matrix_input/, ejecuta los algoritmos Naive y Strassen, mide tiempo y memoria, y guarda los resultados en data/matrix_output/ y data/measurements/.

### Scripts

matrix_generator.py: Genera las matrices de entrada en data/matrix_input/.
plot_generator.py: Lee los CSVs de data/measurements/ y genera gráficos en data/plots/.

## Ordenamiento de arreglo unidimensional

Algoritmos: MergeSort, QuickSort, PatienceSort, std::sort.

### Programa principal

sorting.cpp: Lee los arreglos de entrada desde data/array_input/, ejecuta los 4 algoritmos de ordenamiento, mide tiempo y memoria, y guarda los resultados en data/array_output/ y data/measurements/.

### Scripts

array_generator.py: Genera los arreglos de entrada en data/array_input/.
plot_generator.py: Lee los CSVs de data/measurements/ y genera gráficos en data/plots/.