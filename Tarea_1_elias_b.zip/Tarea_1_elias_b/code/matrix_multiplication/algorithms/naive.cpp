#include <iostream>
#include <vector>

using namespace std;

vector<vector<int>> matrix_multiply_naive(const vector<vector<int>>& A, const vector<vector<int>>& B) {
    int N = A.size();

    vector<vector<int>> C(N, vector<int>(N, 0));
    
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            for (int k = 0; k < N; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    
    return C;
}

//Fuentes: https://www.geeksforgeeks.org/dsa/matrix-chain-multiplication-dp-8/
