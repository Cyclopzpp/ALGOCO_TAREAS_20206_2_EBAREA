#include "./algorithms/naive.cpp"
#include "./algorithms/strassen.cpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <chrono>
#include <sys/resource.h>
#include <filesystem>

using namespace std;
namespace fs = std::filesystem;

long get_mem_usage() {
    struct rusage usage;
    getrusage(RUSAGE_SELF, &usage);
    return usage.ru_maxrss;
}

vector<vector<int>> readMatrix(const string& filepath) {
    ifstream in(filepath);
    vector<vector<int>> mat;
    if (!in.is_open()) {
        cerr << "Error al abrir el archivo: " << filepath << endl;
        return mat;
    }
    string line;
    while (getline(in, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        vector<int> row;
        int val;
        while (ss >> val) {
            row.push_back(val);
        }
        if (!row.empty()) {
            mat.push_back(row);
        }
    }
    in.close();
    return mat;
}

void save_matrix(const vector<vector<int>>& mat, const string& filepath) {
    ofstream out(filepath);
    if (!out.is_open()) {
        cerr << "Error al crear el archivo de salida: " << filepath << endl;
        return;
    }
    for (size_t i = 0; i < mat.size(); ++i) {
        for (size_t j = 0; j < mat[i].size(); ++j) {
            out << mat[i][j] << (j == mat[i].size() - 1 ? "" : " ");
        }
        out << "\n";
    }
    out.close();
}

int main() {
    string input_dir = "./data/matrix_input/";
    string output_dir = "./data/matrix_output/";
    string measurements_dir = "./data/measurements/"; 
    
    if (!fs::exists(input_dir)) fs::create_directories(input_dir);
    if (!fs::exists(output_dir)) fs::create_directories(output_dir);
    if (!fs::exists(measurements_dir)) fs::create_directories(measurements_dir);

    auto test_algorithm = [&](const string& algo_name, auto mult_func, const vector<vector<int>>& A, const vector<vector<int>>& B, const string& base_filename) {
        
        auto start_time = chrono::high_resolution_clock::now();
        
        vector<vector<int>> C = mult_func(A, B);
        
        auto end_time = chrono::high_resolution_clock::now();
        long mem_after = get_mem_usage();
        
        chrono::duration<double, milli> duration = end_time - start_time;
        
        string out_file = output_dir + base_filename + "_out.txt";
        save_matrix(C, out_file);
        
        string out_csv_file = measurements_dir + algo_name + "_matrix_measurements.csv";
        bool write_header = !fs::exists(out_csv_file) || fs::file_size(out_csv_file) == 0;
        
        ofstream csv(out_csv_file, ios::app); 
        if (write_header) {
            csv << "Algorithm,File,Time_ms,Memory_KB\n";
        }
        
        csv << algo_name << "," << base_filename << "," << duration.count() << "," << mem_after << "\n";
        csv.close();
    };

    for (const auto& entry : fs::directory_iterator(input_dir)) {
        if (entry.is_regular_file() && entry.path().extension() == ".txt") {
            string filename = entry.path().stem().string();
            
            if (filename.length() > 2 && filename.substr(filename.length() - 2) == "_1") {
                string base_name = filename.substr(0, filename.length() - 2); 
                
                string file1 = input_dir + base_name + "_1.txt";
                string file2 = input_dir + base_name + "_2.txt";
                
                if (!fs::exists(file2)) {
                    cerr << "Error: Falta la matriz 2 para el par: " << base_name << endl;
                    continue;
                }
                
                vector<vector<int>> A = readMatrix(file1);
                vector<vector<int>> B = readMatrix(file2);
                
                if (A.empty() || B.empty() || A.size() != B.size()) {
                    cerr << "Error: Matrices vacías o incompatibles en: " << base_name << endl;
                    continue;
                }

                test_algorithm("naive", matrix_multiply_naive, A, B, base_name);
                test_algorithm("strassen", strassen, A, B, base_name);
            }
        }
    }

    return 0;
}
