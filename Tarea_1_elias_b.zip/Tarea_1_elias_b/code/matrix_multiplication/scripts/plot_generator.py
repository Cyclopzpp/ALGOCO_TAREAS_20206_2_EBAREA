import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path as pth

route = pth.cwd().parent
measurements_path = route / "data" / "measurements" 
plot_path = route / "data" / "plots"

def process_data(filepath):
    df = pd.read_csv(filepath)
    df[['N', 'Matrix_Type', 'D_type', 'Variant']] = df['File'].str.split('_', expand=True)
    df['N'] = df['N'].astype(int)
    
    grouped = df.groupby(['N', 'D_type'])[['Time_ms', 'Memory_KB']].mean().reset_index()
    return grouped

df_naive = process_data(measurements_path / "naive_matrix_measurements.csv") 
df_strassen = process_data(measurements_path / "strassen_matrix_measurements.csv")

def plot_comparison_separated(df, algorithm_name, complexity, c_factor):

    plt.figure(figsize=(8, 6))
    
    for d_type in df['D_type'].unique():
        subset = df[df['D_type'] == d_type].sort_values('N')
        plt.plot(subset['N'], subset['Time_ms'], marker='o', label=f'Real: {d_type}')
    
    n_values = np.sort(df['N'].unique())
    if complexity == "O(N^3)":
        theoretical_time = c_factor * (n_values ** 3)
    elif complexity == "O(N^2.81)": 
        theoretical_time = c_factor * (n_values ** np.log2(7))
    else:
        theoretical_time = c_factor * (n_values ** 2) 

    plt.plot(n_values, theoretical_time, linestyle='--', color='red', label=f'Teórico: {complexity}')
    
    plt.title(f'{algorithm_name} - Tiempo de Ejecución')
    plt.xlabel('Tamaño de Matriz (N)')
    plt.ylabel('Tiempo (ms)')
    plt.xscale('log', base=2)
    plt.yscale('log', base=10)
    plt.legend()
    plt.grid(True, which="both", ls="-", alpha=0.2)
    plt.tight_layout()
    
    ruta_tiempo = plot_path / f"{algorithm_name.lower()}_time_graph.png"
    plt.savefig(ruta_tiempo, dpi=300)
    print(f"Guardado: {ruta_tiempo}")
    plt.close()

    plt.figure(figsize=(8, 6))
    for d_type in df['D_type'].unique():
        subset = df[df['D_type'] == d_type].sort_values('N')
        plt.plot(subset['N'], subset['Memory_KB'], marker='s', label=f'Real: {d_type}')
        
    plt.title(f'{algorithm_name} - Uso de Memoria')
    plt.xlabel('Tamaño de Matriz (N)')
    plt.ylabel('Memoria (KB)')
    plt.xscale('log', base=2)
    plt.legend()
    plt.grid(True, which="both", ls="-", alpha=0.2)
    plt.tight_layout()
    
    ruta_memoria = plot_path / f"{algorithm_name.lower()}_memory_graph.png"
    plt.savefig(ruta_memoria, dpi=300)
    print(f"Guardado: {ruta_memoria}")
    plt.close()

plot_comparison_separated(df_naive, "Naive", "O(N^3)", c_factor=1e-6)
plot_comparison_separated(df_strassen, "Strassen", "O(N^2.81)", c_factor=5e-5)
