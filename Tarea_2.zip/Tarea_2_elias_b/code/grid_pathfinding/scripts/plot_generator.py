"""
Script para generar gráficos a partir de las mediciones experimentales.
Lee los resultados desde data/measurements/ y guarda los gráficos en data/plots/.

Métricas a graficar:
- Tiempo de ejecución vs tamaño (N * M) para cada algoritmo y tipo de grilla.
- Uso de memoria vs tamaño para cada algoritmo.
- Brecha de puntaje Delta = s(OPT) - s(Greedy) para casos donde greedy encuentra solución.
- Tasa de falla de Greedy (% de casos con 'SIN SOLUCION') según tipo de grilla y dominio.
"""

import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

MEASUREMENTS_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "measurements")
PLOTS_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "plots")

CSV_COLS = ["filename", "n", "m", "v", "p", "time_ms", "mem_kb", "score_raw"]
ALGO_FILES = {
    "BruteForce.csv": "Brute Force",
    "DP.csv": "DP",
    "Greedy.csv": "Greedy",
}
TIPOS_ORDEN = ["libre", "murallas", "minas", "mixta"]


def _parse_metadata(df: pd.DataFrame) -> pd.DataFrame:
    """Extrae metadatos del nombre de archivo {n}_{m}_{t}_{d}_{s} y calcula N * M."""
    df = df.copy()
    parts = df["filename"].astype(str).str.split("_", expand=True)
    df["tipo"] = parts[2] if parts.shape[1] > 2 else "desconocido"
    df["dominio"] = parts[3] if parts.shape[1] > 3 else "desconocido"
    df["muestra"] = parts[4] if parts.shape[1] > 4 else ""
    df["n"] = pd.to_numeric(df["n"], errors="coerce")
    df["m"] = pd.to_numeric(df["m"], errors="coerce")
    df["time_ms"] = pd.to_numeric(df["time_ms"], errors="coerce")
    df["mem_kb"] = pd.to_numeric(df["mem_kb"], errors="coerce")
    df["size"] = df["n"] * df["m"]
    df["found"] = df["score_raw"].astype(str).str.strip() != "SIN SOLUCION"
    df["score"] = pd.to_numeric(df["score_raw"], errors="coerce")
    return df


def load_measurements(measurements_dir: str) -> pd.DataFrame:
    """Carga y unifica los CSV de mediciones desde data/measurements/."""
    frames = []
    if not os.path.isdir(measurements_dir):
        return pd.DataFrame(columns=CSV_COLS + ["algoritmo", "tipo", "dominio", "muestra", "size", "found", "score"])

    for fname in sorted(os.listdir(measurements_dir)):
        if not fname.endswith(".csv"):
            continue
        fpath = os.path.join(measurements_dir, fname)
        if os.path.getsize(fpath) == 0:
            continue

        alg_name = ALGO_FILES.get(fname, os.path.splitext(fname)[0])
        df = pd.read_csv(fpath, header=None, names=CSV_COLS)
        df = df.drop_duplicates(subset=["filename"], keep="last")
        df["algoritmo"] = alg_name
        frames.append(_parse_metadata(df))

    if not frames:
        return pd.DataFrame(columns=CSV_COLS + ["algoritmo", "tipo", "dominio", "muestra", "size", "found", "score"])

    return pd.concat(frames, ignore_index=True)


def plot_time_vs_size(df: pd.DataFrame, out_dir: str) -> None:
    """Tiempo de ejecución vs tamaño (N * M) para cada algoritmo y tipo de grilla."""
    tipos_presentes = [t for t in TIPOS_ORDEN if t in df["tipo"].unique()]
    if not tipos_presentes:
        tipos_presentes = sorted(df["tipo"].dropna().unique())

    n_panels = max(1, len(tipos_presentes))
    fig, axes = plt.subplots(1, n_panels, figsize=(5.2 * n_panels, 5.0), squeeze=False)

    estilos = {
        "Brute Force": ("#d62728", "o"),
        "DP": ("#1f77b4", "s"),
        "Greedy": ("#2ca02c", "^"),
    }

    for idx, tipo in enumerate(tipos_presentes):
        ax = axes[0][idx]
        sub_tipo = df[df["tipo"] == tipo]
        for alg in ["Brute Force", "DP", "Greedy"]:
            sub = sub_tipo[sub_tipo["algoritmo"] == alg]
            if sub.empty:
                continue
            grp = sub.groupby("size", as_index=False)["time_ms"].mean().sort_values("size")
            color, marker = estilos.get(alg, (None, "o"))
            ax.plot(grp["size"], grp["time_ms"], marker=marker, color=color, linewidth=2, label=alg)

        ax.set_xscale("log", base=2)
        ax.set_yscale("log")
        ax.set_title(f"Tipo: {tipo}")
        ax.set_xlabel("Tamaño (N × M)")
        ax.set_ylabel("Tiempo promedio (ms)" if idx == 0 else "")
        ax.grid(True, which="both", linestyle="--", alpha=0.4)
        ax.legend(fontsize=8)

    fig.suptitle("Tiempo de ejecución vs. Tamaño de grilla por tipo", fontsize=13)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "tiempo_vs_tamano.png"), dpi=300)
    plt.close()


def plot_memory_vs_size(df: pd.DataFrame, out_dir: str) -> None:
    """Uso de memoria vs tamaño (N * M) para cada algoritmo."""
    plt.figure(figsize=(8.0, 5.2))

    estilos = {
        "Brute Force": ("#d62728", "o"),
        "DP": ("#1f77b4", "s"),
        "Greedy": ("#2ca02c", "^"),
    }

    for alg in ["Brute Force", "DP", "Greedy"]:
        sub = df[df["algoritmo"] == alg].copy()
        if sub.empty:
            continue
        sub["mem_clean"] = sub["mem_kb"].clip(lower=0)
        grp = sub.groupby("size", as_index=False)["mem_clean"].mean().sort_values("size")
        color, marker = estilos.get(alg, (None, "o"))
        plt.plot(grp["size"], grp["mem_clean"], marker=marker, color=color, linewidth=2, label=alg)

    plt.xscale("log", base=2)
    plt.xlabel("Tamaño (N × M)")
    plt.ylabel("Memoria VmRSS promedio (KB)")
    plt.title("Uso de memoria vs. Tamaño de grilla por algoritmo")
    plt.grid(True, which="both", linestyle="--", alpha=0.4)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "memoria_vs_tamano.png"), dpi=300)
    plt.close()


def plot_greedy_gap(df: pd.DataFrame, out_dir: str) -> None:
    """Brecha Delta = s(OPT) - s(Greedy) donde Greedy encuentra solución."""
    df_dp = df[df["algoritmo"] == "DP"][["filename", "size", "tipo", "dominio", "found", "score"]]
    df_gd = df[df["algoritmo"] == "Greedy"][["filename", "found", "score"]]

    if df_dp.empty or df_gd.empty:
        return

    merged = pd.merge(df_dp, df_gd, on="filename", suffixes=("_opt", "_gd"))
    valid = merged[merged["found_opt"] & merged["found_gd"]].copy()
    if valid.empty:
        return

    valid["delta"] = (valid["score_opt"] - valid["score_gd"]).clip(lower=0)

    fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.0))

    # Panel 1: Brecha promedio por tipo y dominio
    ax = axes[0]
    tipos_presentes = [t for t in TIPOS_ORDEN if t in valid["tipo"].unique()]
    dominios = sorted(valid["dominio"].dropna().unique())
    x = np.arange(len(tipos_presentes))
    width = 0.8 / max(1, len(dominios))

    for idx, dom in enumerate(dominios):
        sub_dom = valid[valid["dominio"] == dom]
        means = [
            sub_dom[sub_dom["tipo"] == t]["delta"].mean() if not sub_dom[sub_dom["tipo"] == t].empty else 0.0
            for t in tipos_presentes
        ]
        offset = (idx - (len(dominios) - 1) / 2) * width
        bars = ax.bar(x + offset, means, width, label=dom)
        ax.bar_label(bars, fmt="%.1f", padding=2, fontsize=8)

    ax.set_xticks(x)
    ax.set_xticklabels(tipos_presentes)
    ax.set_ylabel("Brecha promedio Δ = s(OPT) - s(Greedy)")
    ax.set_title("Brecha Δ por tipo y dominio")
    ax.set_yscale("symlog", linthresh=10)
    ax.grid(True, axis="y", linestyle="--", alpha=0.4)
    ax.legend()

    # Panel 2: Brecha promedio vs tamaño (N * M)
    ax2 = axes[1]
    for dom, marker in [("D10", "o"), ("D1000", "s")]:
        sub_dom = valid[valid["dominio"] == dom]
        if sub_dom.empty:
            continue
        grp = sub_dom.groupby("size", as_index=False)["delta"].mean().sort_values("size")
        ax2.plot(grp["size"], grp["delta"], marker=marker, linewidth=2, label=dom)

    ax2.set_xscale("log", base=2)
    ax2.set_yscale("symlog", linthresh=10)
    ax2.set_xlabel("Tamaño (N × M)")
    ax2.set_ylabel("Brecha promedio Δ (escala symlog)")
    ax2.set_title("Brecha Δ vs. Tamaño de grilla")
    ax2.grid(True, which="both", linestyle="--", alpha=0.4)
    ax2.legend()

    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "brecha_greedy.png"), dpi=300)
    plt.close()


def plot_greedy_failure_rate(df: pd.DataFrame, out_dir: str) -> None:
    """Tasa de falla de Greedy (% de casos con 'SIN SOLUCION') según tipo y dominio."""
    df_gd = df[df["algoritmo"] == "Greedy"].copy()
    if df_gd.empty:
        return

    df_gd["failure_pct"] = (~df_gd["found"]).astype(float) * 100.0
    tipos_presentes = [t for t in TIPOS_ORDEN if t in df_gd["tipo"].unique()]
    dominios = sorted(df_gd["dominio"].dropna().unique())

    plt.figure(figsize=(8.5, 5.2))
    x = np.arange(len(tipos_presentes))
    width = 0.8 / max(1, len(dominios))

    for idx, dom in enumerate(dominios):
        sub_dom = df_gd[df_gd["dominio"] == dom]
        rates = [
            sub_dom[sub_dom["tipo"] == t]["failure_pct"].mean() if not sub_dom[sub_dom["tipo"] == t].empty else 0.0
            for t in tipos_presentes
        ]
        offset = (idx - (len(dominios) - 1) / 2) * width
        bars = plt.bar(x + offset, rates, width, label=dom)
        plt.bar_label(bars, fmt="%.1f%%", padding=2, fontsize=8)

    plt.xticks(x, tipos_presentes)
    plt.ylim(0, 110)
    plt.xlabel("Tipo de grilla")
    plt.ylabel("Tasa de falla (%)")
    plt.title("Tasa de falla de Greedy según tipo de grilla y dominio")
    plt.grid(True, axis="y", linestyle="--", alpha=0.4)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "tasa_falla_greedy.png"), dpi=300)
    plt.close()


def main():
    os.makedirs(PLOTS_DIR, exist_ok=True)
    df = load_measurements(MEASUREMENTS_DIR)
    if df.empty:
        print("No se encontraron datos de mediciones en:", MEASUREMENTS_DIR)
        return

    plot_time_vs_size(df, PLOTS_DIR)
    plot_memory_vs_size(df, PLOTS_DIR)
    plot_greedy_gap(df, PLOTS_DIR)
    plot_greedy_failure_rate(df, PLOTS_DIR)
    print("Gráficos generados en:", PLOTS_DIR)


if __name__ == "__main__":
    main()