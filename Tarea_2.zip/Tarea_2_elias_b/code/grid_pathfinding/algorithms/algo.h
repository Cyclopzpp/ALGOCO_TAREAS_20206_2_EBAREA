#include <bits/stdc++.h>

using namespace std;

#ifndef PATH_RESULT_H
#define PATH_RESULT_H
struct PathResult {
    bool found;
    long long score;
    string path;
    int remaining_lives;
};
#endif

// Firmas de los algoritmos definidos en algorithms/
PathResult solveBruteForce(int n, int m, int v, int p, const vector<vector<int>>& types, const vector<vector<long long>>& values);

PathResult solveDP(int n, int m, int v, int p, const vector<vector<int>>& types, const vector<vector<long long>>& values);

PathResult solveGreedy(int n, int m, int v, int p, const vector<vector<int>>& types, const vector<vector<long long>>& values);