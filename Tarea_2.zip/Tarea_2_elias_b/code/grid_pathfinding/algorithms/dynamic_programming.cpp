#include <bits/stdc++.h>
#include "algo.h"

using namespace std;

void TryPathDP(PathResult& sdp, int n, int m, int v, int p, const vector<vector<int>>& types, const vector<vector<long long>>& values){
    if(n <= 0 || m <= 0 || v <= 0) return ;
    if(types[0][0] == 0 || types[n - 1][m - 1] == 0) return ;
    const long long INF = 4e18 ;
    vector<vector<vector<long long>>> dp(n, vector<vector<long long>>(m, vector<long long>(v + 1, -INF))) ;
    
    dp[0][0][v] = values[0][0] ;

    for(int i = 0 ; i < n ; ++i){
        for(int j = 0 ; j < m ; ++j){
            for(int lvs = 1 ; lvs <= v ; ++lvs){
                if(dp[i][j][lvs] == -INF) continue ;

                if(j + 1 < m){
                    int nt = types[i][j + 1] ;
                    if(nt != 0){
                        int nxt_lvs = lvs ;
                        long long nxt_scr = dp[i][j][lvs] ;
                        
                        if(nt == 1) nxt_scr += values[i][j + 1] ;
                        else if(nt == -1){
                            nxt_lvs -= 1 ;
                            nxt_scr -= p ;
                        }
                        if(nxt_lvs >= 1) {
                            if(nxt_scr > dp[i][j + 1][nxt_lvs]) {
                                dp[i][j + 1][nxt_lvs] = nxt_scr ;
                            }
                        }
                    }
                }

                if(i + 1 < n){
                    int nt = types[i + 1][j] ;
                    if(nt != 0){
                        int nxt_lvs = lvs ;
                        long long nxt_scr = dp[i][j][lvs] ; 
                        
                        if(nt == 1) nxt_scr += values[i + 1][j] ;
                        else if(nt == -1){
                            nxt_lvs -= 1 ;
                            nxt_scr -= p ;
                        }
                        if(nxt_lvs >= 1) {
                            if(nxt_scr > dp[i + 1][j][nxt_lvs]) {
                                dp[i + 1][j][nxt_lvs] = nxt_scr ;
                            }
                        }
                    }
                }
            }
        }
    }

    long long max_scr = -INF ;
    int bst_lvs = -1 ;
    for(int lvs = 1 ; lvs <= v ; ++lvs){
        if(dp[n - 1][m - 1][lvs] > max_scr){
            max_scr = dp[n - 1][m - 1][lvs] ;
            bst_lvs = lvs ;
        }
    }

    if(max_scr == -INF || bst_lvs == -1) {
        sdp.found = false ;
        return ;
    }

    sdp.found = true ;
    sdp.score = max_scr ;
    sdp.remaining_lives = bst_lvs ;
    
    string mvs = "" ;
    int curri = n - 1 ;
    int currj = m - 1 ;
    int currl = bst_lvs ;

    while(curri > 0 || currj > 0){
        bool moo = false ;
        
        if(curri > 0){
            int previ = curri - 1 ;
            int prevj = currj ;
            int nt = types[curri][currj] ;
            int prevl = currl ;
            long long exp_prev_scr = dp[curri][currj][currl] ;
            
            if(nt == 1){
                exp_prev_scr -= values[curri][currj] ;
                prevl = currl ; 
            } else if(nt == -1){
                exp_prev_scr += p ;
                prevl = currl + 1 ;
            }
            
            if(prevl <= v && dp[previ][prevj][prevl] == exp_prev_scr){
                mvs += 'D' ;
                curri = previ ;
                currj = prevj ;
                currl = prevl ;
                moo = true ;
                continue ;
            }
        }
        
        if(!moo && currj > 0){
            int previ = curri ;
            int prevj = currj - 1 ; 
            int nt = types[curri][currj] ;
            int prevl = currl ;
            long long exp_prev_scr = dp[curri][currj][currl] ;
            
            if(nt == 1){
                exp_prev_scr -= values[curri][currj] ;
                prevl = currl ;
            } else if(nt == -1){
                exp_prev_scr += p ;
                prevl = currl + 1 ;
            }
            
            if(prevl <= v && dp[previ][prevj][prevl] == exp_prev_scr){
                mvs += 'R' ;
                curri = previ ;
                currj = prevj ;
                currl = prevl ; 
                moo = true ;
                continue ;
            }
        }
    
        if(!moo){
            break ;
        }
    }
    reverse(mvs.begin(), mvs.end()) ;
    sdp.path = mvs ;
}

PathResult solveDP(int n, int m, int v, int p, const vector<vector<int>>& types, const vector<vector<long long>>& values){
    PathResult sdp ;
    sdp.found = false ;
    sdp.score = 0 ;
    sdp.path = "" ;
    sdp.remaining_lives = 0 ;
    TryPathDP(sdp, n, m, v, p, types, values) ;
    return sdp ;
}
