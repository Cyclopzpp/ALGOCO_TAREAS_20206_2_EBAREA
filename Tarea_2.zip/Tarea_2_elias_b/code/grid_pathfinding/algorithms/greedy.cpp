#include <bits/stdc++.h>
#include "algo.h"

using namespace std ;

void TryPathGD(PathResult& sgd, int n, int m, int v, int p, const vector<vector<int>>& types, const vector<vector<long long>>& values){
    if(types[0][0]==0||types[n - 1][m - 1] == 0) return ;
    int curri = 0 ;
    int currj = 0 ;
    int currl = v ;
    long long tot_scr = values[0][0] ;
    string moves = "" ;

    while(curri < n - 1 || currj < m - 1){
        long long bst_gain = -4e18 ;
        int nexti = -1 ;
        int nextj = -1 ;
        char nextm = ' ' ;
        int nextl = currl ;

        if(currj + 1 < m){
            int nt = types[curri][currj + 1] ;
            if(nt != 0 && !(currl == 1 && nt == -1)){
                long long gain = (nt == 1) ? values[curri][currj + 1] : -p ;
                if(gain > bst_gain){
                    bst_gain = gain ;
                    nexti = curri ;
                    nextj = currj + 1 ;
                    nextm = 'R' ;
                    nextl = (nt == -1) ? currl - 1 : currl ;
                }
            }
        }

        if(curri + 1 < n){
            int nt = types[curri + 1][currj] ;
            if(nt != 0 && !(currl == 1 && nt == -1)){
                long long gain = (nt == 1) ? values[curri + 1][currj] : -p ;
                if(gain > bst_gain){
                    bst_gain = gain ;
                    nexti = curri + 1 ;
                    nextj = currj ;
                    nextm = 'D' ;
                    nextl = (nt == -1) ? currl - 1 : currl ;
                }
            }
        }
        if(nextm == ' ' || nextl < 1){
            sgd.found = false ;
            return ;
        }
        curri = nexti ;
        currj = nextj ;
        currl = nextl ;
        tot_scr += bst_gain ;
        moves += nextm ;
    }
    if(curri == n - 1 && currj == m - 1 && currl >= 1){
        sgd.found = true ;
        sgd.score = tot_scr ;
        sgd.path = moves ;
        sgd.remaining_lives = currl ;
    } else sgd.found = false ;
}

PathResult solveGreedy(int n, int m, int v, int p, const vector<vector<int>>& types, const vector<vector<long long>>& values){
    PathResult sgd ;
    sgd.found = false ;
    sgd.score = 0 ;
    sgd.path = "" ;
    sgd.remaining_lives = v ;
    TryPathGD(sgd, n, m, v, p, types, values) ;
    return sgd ;
}
