#include <bits/stdc++.h>
#include "algo.h"

using namespace std ;

const long long I = -4e18 ;


void TryPathBF(int x, int y, long long ptje_act, int vid_act, string path_act, 
             PathResult &sbf, int n, int m, int p, 
             const vector<vector<int>>& types, const vector<vector<long long>>& values){
    if(x < 0 || x >= n || y < 0 || y >= m) return ;
    if(types[x][y] == 0) return ;
    if(types[x][y] == -1){
        vid_act-- ;
        ptje_act -= p ;
        if(vid_act == 0) return ;
    } else ptje_act += values[x][y] ;

    if(x == n - 1 && y == m - 1){
        if(!sbf.found || ptje_act > sbf.score){
            sbf.found = true ;
            sbf.score = ptje_act ;
            sbf.path = path_act ;
            sbf.remaining_lives = vid_act ;
        }
        return ;
    }
    if(y + 1 < m) TryPathBF(x, y + 1, ptje_act, vid_act, path_act + "R", sbf, n, m, p, types, values) ;
    if(x + 1 < n) TryPathBF(x + 1, y, ptje_act, vid_act, path_act + "D", sbf, n, m, p, types, values) ;
    }

PathResult solveBruteForce(int n, int m, int v, int p, const vector<vector<int>>& types, const vector<vector<long long>>& values){
    PathResult sbf ;
    sbf.found = false ;
    sbf.score = -I ;
    sbf.path = "" ;
    sbf.remaining_lives = -1 ;
    TryPathBF(0, 0, 0LL, v, "", sbf, n, m, p, types, values) ;
    return sbf ;
}
