#include <bits/stdc++.h>
#include <sys/resource.h>
#include <filesystem>
#include "algorithms/algo.h"

using namespace std ;
namespace fs = filesystem ;

long long getCurrentMemoryKB() {
    long long vmrss = 0 ;
    ifstream file("/proc/self/status");
    string line ;
    while (getline(file, line)) {
        if (line.compare(0, 6, "VmRSS:") == 0) {
            istringstream iss(line.substr(6)) ;
            iss >> vmrss ;
            break ;
        }
    }
    return vmrss ;
}

int main(int argc, char* argv[]) {
    (void) argc ;
    (void) argv ;
    string input_dir = "data/grid_input/" ;
    string output_dir = "data/grid_output/" ;
    string measure_dir = "data/measurements/" ;
    int n, m, v, p ;

    for(const auto& entry : fs::directory_iterator(input_dir)){
        string path_file = entry.path().string() ;
        string filename = entry.path().stem().string() ;
        cout << "Usando: " << filename << ".txt" << endl ;
        
        // Lectura directa del archivo de entrada integrada en el main
        ifstream infile(path_file);
        if(!infile.is_open()){
            cerr << "Error al abrir el archivo: " << path_file << endl;
            continue;
        }

        infile >> n >> m >> v >> p ;

        vector<vector<int>> types(n, vector<int>(m));
        for(int i = 0; i < n; ++i){
            for(int j = 0; j < m; ++j){
                infile >> types[i][j];
            }
        }

        vector<vector<long long>> values(n, vector<long long>(m));
        for(int i = 0; i < n; ++i){
            for(int j = 0; j < m; ++j){
                infile >> values[i][j];
            }
        }
        infile.close();
        
        //BruteForce
        if(n + m <= 32){
            auto start_bf = chrono::high_resolution_clock::now() ;
            long long mem_start_bf = getCurrentMemoryKB() ;
            PathResult res_bf = solveBruteForce(n, m, v, p, types, values) ;
            auto end_bf = chrono::high_resolution_clock::now() ;
            long long mem_end_bf = getCurrentMemoryKB() ;
            chrono::duration<double, milli> diff_bf = end_bf - start_bf ;
            long long mem_bf = mem_end_bf - mem_start_bf ;
            string out_bf_path = output_dir + filename + "_bruteforce_out.txt" ;
            ofstream out_bf(out_bf_path) ;
            if(out_bf.is_open()){
                if(res_bf.found) out_bf << res_bf.score << "\n" << res_bf.path << "\n" << res_bf.remaining_lives << "\n" ;
                else out_bf << "SIN SOLUCION\n" ;
            }

            string meas_bf_path = measure_dir + "BruteForce.csv" ;
            ofstream meas_bf(meas_bf_path, ios::app) ;
            if(meas_bf.is_open()) {
                meas_bf << filename << "," << n << "," << m << "," << v << "," << p 
                << "," << diff_bf.count() << "," << mem_bf << "," ;
            
                if(res_bf.found) {
                    meas_bf << res_bf.score << "\n" ;
                } else {
                    meas_bf << "SIN SOLUCION\n" ;
                }
            }
        }
        
        // DP
        auto start_dp = chrono::high_resolution_clock::now() ;
        long long mem_start_dp = getCurrentMemoryKB() ;
        PathResult res_dp = solveDP(n, m, v, p, types, values) ;
        auto end_dp = chrono::high_resolution_clock::now() ;
        long long mem_end_dp = getCurrentMemoryKB() ;
        chrono::duration<double, milli> diff_dp = end_dp - start_dp ;
        long long mem_dp = mem_end_dp - mem_start_dp ;
        string out_dp_path = output_dir + filename + "_dp_out.txt" ;
        ofstream out_dp(out_dp_path) ;
        if(out_dp.is_open()){
            if(res_dp.found) out_dp << res_dp.score << "\n" << res_dp.path << "\n" << res_dp.remaining_lives << "\n" ;
            else out_dp << "SIN SOLUCION\n" ;
        }

        string meas_dp_path = measure_dir + "DP.csv" ;
        ofstream meas_dp(meas_dp_path, ios::app) ;
        if(meas_dp.is_open()){
            meas_dp << filename << "," << n << "," << m << "," << v << "," << p 
                << "," << diff_dp.count() << "," << mem_dp << "," ;

            if(res_dp.found) {
                meas_dp << res_dp.score << "\n" ;
            } else {
                meas_dp << "SIN SOLUCION\n" ;
            }
        }
        
        // Greedy
        auto start_gd = chrono::high_resolution_clock::now() ;
        long long mem_start_gd = getCurrentMemoryKB() ;
        PathResult res_gd = solveGreedy(n, m, v, p, types, values) ;
        auto end_gd = chrono::high_resolution_clock::now() ;
        long long mem_end_gd = getCurrentMemoryKB() ;
        chrono::duration<double, milli> diff_gd = end_gd - start_gd ;
        long long mem_gd = mem_end_gd - mem_start_gd ;
        string out_gd_path = output_dir + filename + "_greedy_out.txt" ;
        ofstream out_gd(out_gd_path) ;
        if(out_gd.is_open()){
            if(res_gd.found) out_gd << res_gd.score << "\n" << res_gd.path << "\n" << res_gd.remaining_lives << "\n" ;
            else out_gd << "SIN SOLUCION\n" ;
        }

        string meas_gd_path = measure_dir + "Greedy.csv" ;
        ofstream meas_gd(meas_gd_path, ios::app) ;
        if(meas_gd.is_open()){
            meas_gd << filename << "," << n << "," << m << "," << v << "," << p 
                << "," << diff_gd.count() << "," << mem_gd << "," ;

            if(res_gd.found) {
                meas_gd << res_gd.score << "\n" ;
            } else {
                meas_gd << "SIN SOLUCION\n" ;
            }
        }
    }
    cout << "Programa principal de Grid Pathfinding finalizado" << endl ;
    return 0 ;
}
