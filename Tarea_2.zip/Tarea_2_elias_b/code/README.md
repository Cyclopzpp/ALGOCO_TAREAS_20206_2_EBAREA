# Documentación

## Entrega

La entrega se realiza vía *aula.usm.cl* en formato `.zip`.

## Grid pathfinding

Algoritmos: Fuerza Bruta, Programación Dinámica, Greedy.

### Programa principal

`grid_pathfinding.cpp`: Lee las grillas de entrada desde `data/grid_input/`, ejecuta Fuerza Bruta (para instancias con $N + M \le 32$), Programación Dinámica y Greedy, mide tiempo y memoria, y guarda los resultados en `data/grid_output/` y `data/measurements/`.

El struct inicial (`PathResult`) y las firmas de los algoritmos quedaron en el header `algorithms/algo.h`, de manera que las dependencias siguen el flujo `algo.h` -> algoritmos (`brute_force.cpp`, `dynamic_programming.cpp`, `greedy.cpp`) -> `grid_pathfinding.cpp`.

### Estructura de archivos

```bash
.
├── grid_pathfinding.cpp
├── makefile
├── algorithms
│   ├── algo.h
│   ├── brute_force.cpp
│   ├── dynamic_programming.cpp
│   └── greedy.cpp
├── data
│   ├── grid_input
│   ├── grid_output
│   ├── measurements
│   └── plots
└── scripts
    └── plot_generator.py
```

### Scripts

`plot_generator.py`: Lee los CSVs de `data/measurements/` y genera gráficos en `data/plots/`.